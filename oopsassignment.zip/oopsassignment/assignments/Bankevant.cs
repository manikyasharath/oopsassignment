﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    internal class Bankevant
    {

        delegate void digSimple();
        class Exercise
        {
            public static event digSimple UnderBalanceEvent;
            public static event digSimple ZeroBalanceEvent;



            public static void UnderBalance()
            {
                Console.WriteLine("youer balance is under 1000 rupees please deposit the money :");
            }



            public static void UnderAmount()
            {
                UnderBalanceEvent();
            }



            public static void ZeroBalance()
            {
                Console.WriteLine("your balance is zero please deposite the meny to your account :");
            }



            public static void ZeroAmount()
            {
                ZeroBalanceEvent();
            }




            public static void Main()
            {




                UnderBalanceEvent += new digSimple(UnderBalance);
                UnderAmount();
                ZeroBalanceEvent += new digSimple(ZeroBalance);
                ZeroAmount();




                Console.ReadKey();
            }



        }


    }
}
