﻿using System;
internal class swapping
{
    public static void Swap()
    {
        int a = 5, b = 6, temp;
        Console.WriteLine("Before Swapping a= {0}, b= {1}", a, b);
        temp = a;
        a = b;
        b = temp;
        Console.WriteLine("After Swapping a= {0}, b= {1}", a, b);
    }
    public static void Main()
    {
        Swap();
        Console.ReadLine();
    }
}