﻿namespace assignment1
{
    struct StructBookEnymType
    {
        enum BookType
        {
            Magazine,
            Novel,
            ReferenceBook,
            Miscellaneous
        }
        public static void Book()
        {
            int BookId;
            String Title;
            double Price;
            Console.WriteLine("Enter The BookId:");
            BookId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter The Title :");
            Title = Console.ReadLine();
            Console.WriteLine("Enter The Book Price :");
            Price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("The BookId:" + BookId);
            Console.WriteLine("The Title Of The Book is :" + Title);
            Console.WriteLine("The Price Of The Book is :" + Price);
            Console.WriteLine("The BookType is :" + BookType.Magazine);
        }
        public static void Main()
        {
            Book();
            Console.ReadKey();
        }
    }
}