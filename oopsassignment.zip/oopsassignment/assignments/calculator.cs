﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calci
{
    internal class Calculator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number:");
            int a = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter another number:");
            int b = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("1.Addition");
            Console.WriteLine("2.Subtraction");
            Console.WriteLine("3.Multiplication");
            Console.WriteLine("4.Division");
            int c = Convert.ToInt16(Console.ReadLine());
            switch (c)
            {
                case 1:
                    Console.WriteLine("Addition of two numbers:" + (a + b));
                    break;

                case 2:
                    Console.WriteLine("Subtraction of two numbers" + (a - b));
                    break;

                case 3:
                    Console.WriteLine("Multiplication of two numbers" + (a * b));
                    break;

                case 4:
                    Console.WriteLine("divison of two numbers" + (a / b));
                    break;

            }
            Console.ReadLine();
        }
    }
}