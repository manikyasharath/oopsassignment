﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritanceAndpolymorphism
{
    internal class Employee
    {
        protected int empno;
        protected string empname;
        protected double salary;
        protected double hra;
        protected double ta;
        protected double da;
        protected double pf;
        protected double tds;
        protected double netsalary;
        protected double grosssalary;

        public int EmpNo
        {
            get => empno;
        }
        public string Empname
        {
            get => empname;
        }
        public double Salary
        {
            get => salary;
        }


        public double HRA
        {
            get => hra;
        }

        public double TA
        {
            get => ta;
        }

        public double DA
        {
            get => da;
        }

        public double PF
        {
            get => pf;
        }
        public double TDS
        {
            get => tds;
        }

        public double NetSalary
        {
            get => netsalary;
        }
        public double GrossSalary
        {
            get => grosssalary;
        }

        public Employee(int empid, string empnm, double sal)
        {
            empno = empid;
            empname = empnm;
            salary = sal;

            if (salary < 5000)
            {
                hra = ((Salary / 100) * 10);
                ta = ((Salary / 100) * 5);
                da = ((Salary / 100) * 15);
                grosssalary = salary + hra + ta + da;
            }
            else if (salary < 10000)
            {
                hra = ((Salary / 100) * 15);
                ta = ((Salary / 100) * 10);
                da = ((Salary / 100) * 20);
                grosssalary = salary + hra + ta + da;

            }

            else if (salary < 15000)
            {
                hra = ((Salary / 100) * 20);
                ta = ((Salary / 100) * 15);
                da = ((Salary / 100) * 25);
                grosssalary = salary + hra + ta + da;

            }

            else if (salary < 20000)
            {
                hra = ((Salary / 100) * 25);
                ta = ((Salary / 100) * 20);
                da = ((Salary / 100) * 30);
                grosssalary = salary + hra + ta + da;

            }
            else
            {
                hra = ((Salary / 100) * 30);
                ta = ((Salary / 100) * 25);
                da = ((Salary / 100) * 35);
                grosssalary = salary + hra + ta + da;

            }

        }

        public virtual void CalculateSalary()
        {
            pf = (grosssalary / 100) * 10;
            tds = (grosssalary / 100) * 18;
            netsalary = grosssalary - (pf + tds);
            Console.WriteLine("Employee NetSalary : " + netsalary);
        }

        public virtual void Grasalary()
        {
            Console.WriteLine("Employee GrosSalary : " + grosssalary);
        }

    }

    class Manager : Employee
    {
        private double PetrolAllowance;
        private double FoodAllowance;
        private double OtherAllowance;

        public Manager(int empid, string empnm, double sal) : base(empid, empnm, sal)
        {
            PetrolAllowance = salary * 8 / 100;
            FoodAllowance = salary * 13 / 100;
            OtherAllowance = salary * 3 / 100;
        }

        public override void Grasalary()
        {
            grosssalary += PetrolAllowance + FoodAllowance + OtherAllowance;
            Console.WriteLine("manager GrasSalary : " + grosssalary);
        }

        public override void CalculateSalary()
        {
            netsalary = grosssalary - (pf + tds);
            Console.WriteLine("Manager Netsalary : " + netsalary);
        }

    }

    class MarketingExecutive : Employee
    {
        private double Kilometertravel;
        private double TourAllowances;
        private double TelephoneAllowances;

        public double kilometertravel
        {
            get => Kilometertravel;
        }

        public double Tourallowances
        {
            get => TourAllowances;
        }
        public double Telephoneallowances
        {
            get => TelephoneAllowances;
        }
        public MarketingExecutive(int empid, string empnm, double sal, double kilmetr) : base(empid, empnm, sal)
        {
            Kilometertravel = kilmetr;
            TourAllowances = Kilometertravel * 5;
            TelephoneAllowances = 1000;
        }

        public override void Grasalary()
        {
            grosssalary += TourAllowances + TelephoneAllowances;
            Console.WriteLine("MarketingExecutive GrasSalary : " + grosssalary);
        }

        public override void CalculateSalary()
        {
            netsalary = grosssalary - (pf + tds);
            Console.WriteLine("MarketingExecutive NetSalary : " + netsalary);
        }

    }

    class Launch
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Employee Number :");
            int empid = int.Parse(Console.ReadLine());
            Console.WriteLine("Employee Name :");
            string empname = Console.ReadLine();
            Console.WriteLine("Employee Salary :");
            double sal = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Kilometertravel :");
            double kmt = Convert.ToDouble(Console.ReadLine());
            MarketingExecutive me = new MarketingExecutive(empid, empname, sal, kmt);
            Manager m = new Manager(empid, empname, sal);
            //Employee e = new Employee(empid, empname, sal);
            //e.Grasalary();
            //e.CalculateSalary();

            m.Grasalary();
            m.CalculateSalary();

            me.Grasalary();
            me.CalculateSalary();

            Console.ReadKey();
        }
    }
}